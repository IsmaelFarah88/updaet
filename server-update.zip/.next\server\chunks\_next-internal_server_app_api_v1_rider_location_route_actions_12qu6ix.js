module.exports=[59147,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_rider_location_route_actions_12qu6ix.js.map