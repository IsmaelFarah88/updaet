module.exports=[880604,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_auth_forgot-password_route_actions_0gvk379.js.map