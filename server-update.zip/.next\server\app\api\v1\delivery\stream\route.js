var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/delivery/stream/route.js")
R.c("server/chunks/_088ar75._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__02g567n._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_delivery_stream_route_actions_1_ixq3q.js")
R.m(54079)
module.exports=R.m(54079).exports
