globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/qyslL0EP5NT4QjvvLOskN/_buildManifest.js",
    "static/qyslL0EP5NT4QjvvLOskN/_ssgManifest.js",
    "static/qyslL0EP5NT4QjvvLOskN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2m5a65cn7-g0k.js",
    "static/chunks/2-urkx3cuhmdn.js",
    "static/chunks/2-f08ea-ihvso.js",
    "static/chunks/2yji151oqf1m2.js",
    "static/chunks/26g4tn5b226u5.js",
    "static/chunks/turbopack-0hdqh6y2epylc.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
