globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/CPMilrKIrj-edikLPmE4F/_buildManifest.js",
    "static/CPMilrKIrj-edikLPmE4F/_ssgManifest.js",
    "static/CPMilrKIrj-edikLPmE4F/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0d0tnxkii69o6.js",
    "static/chunks/0fy4h0ngk1igg.js",
    "static/chunks/0qnlxa_-yk21e.js",
    "static/chunks/0tbmgmqs724o8.js",
    "static/chunks/1qk-t5kllqob5.js",
    "static/chunks/turbopack-2ns240rxh1wkq.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
