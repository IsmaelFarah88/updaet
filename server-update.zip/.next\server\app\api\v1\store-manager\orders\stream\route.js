var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/orders/stream/route.js")
R.c("server/chunks/_0d1vcjt._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__1mf6-y2._.js")
R.c("server/chunks/1oeh_server_app_api_v1_store-manager_orders_stream_route_actions_0zspleb.js")
R.m(774566)
module.exports=R.m(774566).exports
