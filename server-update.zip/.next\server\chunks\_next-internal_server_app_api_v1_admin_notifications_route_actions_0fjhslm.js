module.exports=[31200,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_admin_notifications_route_actions_0fjhslm.js.map