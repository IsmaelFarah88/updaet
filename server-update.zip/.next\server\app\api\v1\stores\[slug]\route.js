var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/stores/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__03vyf7j._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_stores_[slug]_route_actions_0ujtx-v.js")
R.m(339339)
module.exports=R.m(339339).exports
