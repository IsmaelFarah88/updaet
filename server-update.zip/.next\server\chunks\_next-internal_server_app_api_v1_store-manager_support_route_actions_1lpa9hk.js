module.exports=[71027,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_support_route_actions_1lpa9hk.js.map