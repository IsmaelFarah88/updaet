var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/delivery/available/route.js")
R.c("server/chunks/_0i4oa_9._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__0g7tu57._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_delivery_available_route_actions_161nh-3.js")
R.m(6481)
module.exports=R.m(6481).exports
