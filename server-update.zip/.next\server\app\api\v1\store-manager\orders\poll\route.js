var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/orders/poll/route.js")
R.c("server/chunks/_0kcyi7h._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__1s-gl5z._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_store-manager_orders_poll_route_actions_0os6mhf.js")
R.m(982165)
module.exports=R.m(982165).exports
