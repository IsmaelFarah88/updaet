var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/banners/route.js")
R.c("server/chunks/[root-of-the-server]__03s_hxl._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_banners_route_actions_0s2x-8q.js")
R.m(263383)
module.exports=R.m(263383).exports
