var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/support/route.js")
R.c("server/chunks/[root-of-the-server]__0y58po2._.js")
R.c("server/chunks/_1sc8arb._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_support_route_actions_1jooy-c.js")
R.m(944174)
module.exports=R.m(944174).exports
