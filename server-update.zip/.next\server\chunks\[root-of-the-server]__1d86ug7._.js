module.exports=[27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},82678,e=>{"use strict";var t=e.i(27699),r=e.i(47733),n=e.i(89171);let o=globalThis.orderEventEmitter||new t.EventEmitter;async function s(e){let t=await (0,r.requireAuthUser)(e,["DELIVERY","ADMIN"]);if(t.errorResponse)return t.errorResponse;let s=t.user,a=new ReadableStream({start(t){let r=new TextEncoder;t.enqueue(r.encode(`event: connected
data: ${JSON.stringify({status:"connected",userId:s.userId})}

`));let n=e=>{try{t.enqueue(r.encode(`event: NEW_ORDER
data: ${JSON.stringify(e)}

`))}catch(e){console.error("Delivery SSE enqueue error:",e)}},a="delivery_event:new_order";o.on(a,n);let i=setInterval(()=>{try{t.enqueue(r.encode(`: ping

`))}catch{}},15e3);e.signal.addEventListener("abort",()=>{o.off(a,n),clearInterval(i);try{t.close()}catch{}})}});return new n.NextResponse(a,{headers:{"Content-Type":"text/event-stream","Cache-Control":"no-cache, no-transform",Connection:"keep-alive"}})}o.setMaxListeners(500),globalThis.orderEventEmitter=o,e.s(["GET",0,s,"notifyDeliveryDrivers",0,function(t,r){o.emit(`delivery_event:${t}`,r),e.A(35991).then(({pusherServer:e})=>{e.trigger("delivery-channel",`delivery_event:${t}`,r).catch(e=>{console.warn("Pusher driver notification fallback:",e?.message||e)})}).catch(()=>{})}])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1d86ug7._.js.map