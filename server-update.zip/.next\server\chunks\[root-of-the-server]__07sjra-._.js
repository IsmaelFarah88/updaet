module.exports=[63021,(e,i,r)=>{i.exports=e.x("@prisma/client-2c3a283f134fdcb6",()=>require("@prisma/client-2c3a283f134fdcb6"))},43793,e=>{"use strict";var i=e.i(63021);let r=globalThis.prisma||new i.PrismaClient;e.s(["db",0,r])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__07sjra-._.js.map