module.exports=[62388,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_orders_%5Bid%5D_accept_route_actions_1wbr_a7.js.map