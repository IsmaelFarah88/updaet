module.exports=[35277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_delivery_poll_route_actions_17wjyvf.js.map