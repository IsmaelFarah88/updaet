module.exports=[83841,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_orders_route_actions_1cjl445.js.map