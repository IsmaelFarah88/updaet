module.exports=[95850,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_delivery_stream_route_actions_1_ixq3q.js.map