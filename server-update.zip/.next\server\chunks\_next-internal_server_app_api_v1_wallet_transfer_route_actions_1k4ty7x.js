module.exports=[3703,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_wallet_transfer_route_actions_1k4ty7x.js.map