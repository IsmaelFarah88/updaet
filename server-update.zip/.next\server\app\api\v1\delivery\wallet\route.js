var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/delivery/wallet/route.js")
R.c("server/chunks/_0j64mha._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__1xe_3hr._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_delivery_wallet_route_actions_1fhp4us.js")
R.m(34005)
module.exports=R.m(34005).exports
