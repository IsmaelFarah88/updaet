module.exports=[97983,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_delivery_notify-arrival_route_actions_0v19prr.js.map