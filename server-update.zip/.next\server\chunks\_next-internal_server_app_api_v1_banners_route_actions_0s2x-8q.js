module.exports=[535170,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_banners_route_actions_0s2x-8q.js.map