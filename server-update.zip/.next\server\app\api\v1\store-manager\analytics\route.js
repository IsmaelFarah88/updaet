var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/analytics/route.js")
R.c("server/chunks/_08o2s6n._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__0v63mel._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_store-manager_analytics_route_actions_16k4b1z.js")
R.m(47088)
module.exports=R.m(47088).exports
