var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/delivery/duty/route.js")
R.c("server/chunks/_1_-dimt._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__12j-ehd._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_delivery_duty_route_actions_1n079lx.js")
R.m(49694)
module.exports=R.m(49694).exports
