module.exports=[68140,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_test_route_actions_097c6vi.js.map