var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/coupons/route.js")
R.c("server/chunks/[root-of-the-server]__03enh7t._.js")
R.c("server/chunks/_1sn4955._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_store-manager_coupons_route_actions_0yu8qk0.js")
R.m(86904)
module.exports=R.m(86904).exports
