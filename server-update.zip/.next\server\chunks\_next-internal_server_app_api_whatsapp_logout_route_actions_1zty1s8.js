module.exports=[880704,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_logout_route_actions_1zty1s8.js.map