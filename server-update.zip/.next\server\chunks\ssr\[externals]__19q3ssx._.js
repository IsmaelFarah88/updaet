module.exports=[92097,(a,b,c)=>{b.exports=a.x("punycode",()=>require("punycode"))},6461,(a,b,c)=>{b.exports=a.x("zlib",()=>require("zlib"))}];

//# sourceMappingURL=%5Bexternals%5D__19q3ssx._.js.map