module.exports=[334667,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_support_route_actions_1jooy-c.js.map