module.exports=[66828,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_analytics_route_actions_16k4b1z.js.map