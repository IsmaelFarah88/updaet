module.exports=[58344,a=>{a.v(b=>Promise.all(["server/chunks/ssr/src_actions_delivery_ts_0mw5gby._.js"].map(b=>a.l(b))).then(()=>b(49299)))}];

//# sourceMappingURL=src_actions_delivery_ts_004uhlm._.js.map