module.exports=[38881,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_app-config_route_actions_0qjwtja.js.map