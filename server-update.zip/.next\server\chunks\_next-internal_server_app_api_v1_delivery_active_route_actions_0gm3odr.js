module.exports=[724683,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_delivery_active_route_actions_0gm3odr.js.map