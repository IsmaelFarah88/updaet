var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/app-config/route.js")
R.c("server/chunks/[root-of-the-server]__0c6wiaj._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_app-config_route_actions_0qjwtja.js")
R.m(352822)
module.exports=R.m(352822).exports
