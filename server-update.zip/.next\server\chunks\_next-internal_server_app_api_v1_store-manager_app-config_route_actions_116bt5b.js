module.exports=[72092,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_app-config_route_actions_116bt5b.js.map