var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/stores/route.js")
R.c("server/chunks/[root-of-the-server]__0915r4t._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_stores_route_actions_12l1x6d.js")
R.m(329701)
module.exports=R.m(329701).exports
