var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/products/route.js")
R.c("server/chunks/[root-of-the-server]__1u97ytu._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/_05aunl2._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_store-manager_products_route_actions_08yje7w.js")
R.m(298377)
module.exports=R.m(298377).exports
