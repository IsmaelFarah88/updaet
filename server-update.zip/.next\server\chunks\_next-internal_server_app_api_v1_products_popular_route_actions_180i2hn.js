module.exports=[387201,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_products_popular_route_actions_180i2hn.js.map