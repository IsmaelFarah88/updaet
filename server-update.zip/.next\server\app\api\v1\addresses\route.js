var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/addresses/route.js")
R.c("server/chunks/[root-of-the-server]__1wjz3-_._.js")
R.c("server/chunks/_0r5k-62._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_addresses_route_actions_18-zl1b.js")
R.m(43361)
module.exports=R.m(43361).exports
