module.exports=[541256,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_reviews_route_actions_0-l257p.js.map