module.exports=[7907,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_stores_%5Bslug%5D_route_actions_0ujtx-v.js.map