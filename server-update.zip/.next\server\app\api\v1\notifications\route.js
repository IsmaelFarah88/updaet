var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/notifications/route.js")
R.c("server/chunks/_1e1tew3._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__1m68yu6._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_notifications_route_actions_1jv34bk.js")
R.m(229173)
module.exports=R.m(229173).exports
