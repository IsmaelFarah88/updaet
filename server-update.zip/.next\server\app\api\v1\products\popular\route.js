var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/products/popular/route.js")
R.c("server/chunks/[root-of-the-server]__14ytb8k._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_products_popular_route_actions_180i2hn.js")
R.m(12727)
module.exports=R.m(12727).exports
