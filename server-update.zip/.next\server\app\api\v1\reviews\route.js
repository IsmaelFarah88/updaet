var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/reviews/route.js")
R.c("server/chunks/_0xuzwc1._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__0x1wc0d._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_reviews_route_actions_0-l257p.js")
R.m(895114)
module.exports=R.m(895114).exports
