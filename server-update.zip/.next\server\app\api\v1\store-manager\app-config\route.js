var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/app-config/route.js")
R.c("server/chunks/[root-of-the-server]__1ftcbj_._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_store-manager_app-config_route_actions_116bt5b.js")
R.m(917933)
module.exports=R.m(917933).exports
