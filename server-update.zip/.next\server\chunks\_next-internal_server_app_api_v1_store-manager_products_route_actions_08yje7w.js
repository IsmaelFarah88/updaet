module.exports=[229630,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_products_route_actions_08yje7w.js.map