module.exports=[67990,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_dashboard_route_actions_11x-n5b.js.map