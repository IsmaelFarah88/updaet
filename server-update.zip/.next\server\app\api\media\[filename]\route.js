var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/media/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__0bspv73._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_next-internal_server_app_api_media_[filename]_route_actions_1gfp2zw.js")
R.m(741817)
module.exports=R.m(741817).exports
