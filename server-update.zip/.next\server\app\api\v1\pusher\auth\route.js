var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/pusher/auth/route.js")
R.c("server/chunks/[root-of-the-server]__0676xrj._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/_1_fv8al._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_pusher_auth_route_actions_037bf7j.js")
R.m(74055)
module.exports=R.m(74055).exports
