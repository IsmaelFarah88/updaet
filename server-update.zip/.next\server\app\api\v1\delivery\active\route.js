var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/delivery/active/route.js")
R.c("server/chunks/_1wvkfvu._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__1g166jd._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_delivery_active_route_actions_0gm3odr.js")
R.m(621514)
module.exports=R.m(621514).exports
