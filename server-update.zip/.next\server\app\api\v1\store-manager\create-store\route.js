var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/create-store/route.js")
R.c("server/chunks/_09os4d2._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__0yy1nsx._.js")
R.c("server/chunks/1oeh_server_app_api_v1_store-manager_create-store_route_actions_1cqhsj0.js")
R.m(83903)
module.exports=R.m(83903).exports
