var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/store-manager/support/route.js")
R.c("server/chunks/_11je_rn._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__1g7egm3._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_store-manager_support_route_actions_1lpa9hk.js")
R.m(15881)
module.exports=R.m(15881).exports
