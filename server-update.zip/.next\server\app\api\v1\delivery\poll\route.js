var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/delivery/poll/route.js")
R.c("server/chunks/_1x-u6ez._.js")
R.c("server/chunks/node_modules_jose_dist_webapi_1kzfagc._.js")
R.c("server/chunks/node_modules_next_0q3k5bn._.js")
R.c("server/chunks/[root-of-the-server]__0g06wx7._.js")
R.c("server/chunks/[root-of-the-server]__12ic_hr._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_delivery_poll_route_actions_17wjyvf.js")
R.m(772776)
module.exports=R.m(772776).exports
