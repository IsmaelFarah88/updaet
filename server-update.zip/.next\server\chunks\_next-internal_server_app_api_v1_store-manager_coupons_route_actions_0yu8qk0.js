module.exports=[25221,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_store-manager_coupons_route_actions_0yu8qk0.js.map